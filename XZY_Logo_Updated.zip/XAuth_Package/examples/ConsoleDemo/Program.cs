using System;
using X_Auth;

class Program
{
    // X AUTH style — name / ownerid / secret / version, no API key.
    // Get Owner ID + Secret from: panel -> Install page.
    private static readonly api XAuthApp = new api(
        name:    "APP-1LHEK3",
        ownerid: "IHH231792GMAILCOM-OFPDR",
        secret:  "SEC_fV0a-6poU-U6sp-xmAN-Wimi-j3ZF-D2HE-d5Hh",
        version: "1.0"
    );

    static void Main(string[] args)
    {
        if (args.Length > 0 && args[0] == "--full")
        {
            FullControl();
            return;
        }

        if (args.Length > 0 && args[0] == "--license")
        {
            string lk = args.Length > 1 ? args[1] : "";
            Console.WriteLine("Server : " + api.Server);
            Console.WriteLine("App    : " + XAuthApp.name + " v" + XAuthApp.version);
            Console.Write("init() ");
            XAuthApp.init();
            Console.WriteLine(XAuthApp.response.success ? "OK" : "FAIL: " + XAuthApp.response.message);
            Console.Write("license(" + lk + ") ");
            XAuthApp.license(lk);
            Console.WriteLine(XAuthApp.response.success
                ? "=> LOGIN OK @ " + XAuthApp.response.expiry
                : "=> DENIED: " + XAuthApp.response.message);
            return;
        }

        string user = args.Length > 0 ? args[0] : "username";
        string pass = args.Length > 1 ? args[1] : "password";

        Console.WriteLine("Server : " + api.Server);
        Console.WriteLine("App    : " + XAuthApp.name + " v" + XAuthApp.version);

        Console.Write("init() ");
        XAuthApp.init();
        Console.WriteLine(XAuthApp.response.success ? "OK" : "FAIL: " + XAuthApp.response.message);

        Console.Write("login(" + user + ") ");
        XAuthApp.login(user, pass);
        Console.WriteLine(XAuthApp.response.success
            ? "=> LOGIN OK @ " + XAuthApp.response.expiry
            : "=> DENIED: " + XAuthApp.response.message);

        return;
    }

    // Full control demo: create -> login -> ban -> unban -> login -> delete
    static void FullControl()
    {
        XAuthApp.init();
        Console.WriteLine("Server : " + api.Server);
        Console.WriteLine("App    : " + XAuthApp.name + " (ownerid " + XAuthApp.ownerid + ")");

        string u = "ctl" + Environment.TickCount.ToString("X");

        Console.Write("create(" + u + ") ");
        var c = XAuthApp.Create(u, "pass123", "30d");
        Console.WriteLine(c.ok ? "OK id=" + c.id : "FAIL: " + c.message);
        string id = c.id;

        Console.Write("login(" + u + ") ");
        XAuthApp.login(u, "pass123");
        Console.WriteLine(XAuthApp.response.success ? "LOGIN OK @ " + XAuthApp.response.expiry : "DENIED: " + XAuthApp.response.message);

        Console.Write("ban(" + u + ") ");
        XAuthApp.Ban(id, true);
        Console.WriteLine(XAuthApp.response.message);

        Console.Write("login(" + u + ") again ");
        XAuthApp.login(u, "pass123");
        Console.WriteLine(XAuthApp.response.success ? "OK (UNEXPECTED)" : "DENIED: " + XAuthApp.response.message);

        Console.Write("unban(" + u + ") ");
        XAuthApp.Ban(id, false);
        Console.WriteLine(XAuthApp.response.message);

        Console.Write("delete(" + u + ") ");
        var d = XAuthApp.Delete(id);
        Console.WriteLine(d.ok ? "DELETED" : "FAIL: " + d.message);

        Console.Write("login(" + u + ") after delete ");
        XAuthApp.login(u, "pass123");
        Console.WriteLine(XAuthApp.response.success ? "OK (UNEXPECTED)" : "DENIED: " + XAuthApp.response.message);

        Console.Write("CreateKey(7d) ");
        string lk = XAuthApp.CreateKey("7d");
        Console.WriteLine(lk.Length > 0 ? lk : "FAIL");
        if (lk.Length > 0)
        {
            Console.Write("license(" + lk + ") ");
            XAuthApp.license(lk);
            Console.WriteLine(XAuthApp.response.success ? "LOGIN OK @ " + XAuthApp.response.expiry : "DENIED: " + XAuthApp.response.message);
        }

        Console.WriteLine("== FULL CONTROL OK ==");
    }
}