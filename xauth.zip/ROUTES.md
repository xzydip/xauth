# XzyAuth route navigation

/user                 -> User section
/user/new-user        -> New User button
/user/lisence-key     -> License Key button
/application          -> Application section
/application/new-app  -> New App button
/apikeys              -> API Keys section
/apikeys/gernate      -> Generate API Key button
/dashboard            -> Dashboard

Every button should navigate to its own route rather than forcing the parent section URL.
